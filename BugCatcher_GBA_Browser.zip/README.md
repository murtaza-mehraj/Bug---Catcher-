# Bug Catcher Browser Edition

Created for Murtaza Mehraj.

This version keeps the prototype's core flow:
1. Main menu
2. Start Game
3. Move with a virtual joystick
4. Get close to the bug
5. Press CATCH BUG
6. Timing bar: PERFECT / GOOD / OKAY / MISS
7. Captured bug card
8. Bug Book

The graphics are original pixel-art inspired by the 16-bit handheld era. They are not Pokémon assets.

## Run instantly
Open `index.html` in a modern browser.

## Online
You can paste the HTML into an HTML/JS playground such as CodePen, or put the file in a GitHub repository and run it through a browser-based development environment.

## Controls
- Touch/click the left joystick area to move.
- Move near the ladybug.
- Tap CATCH BUG.
- Tap the timing bar when the marker is near PERFECT.
